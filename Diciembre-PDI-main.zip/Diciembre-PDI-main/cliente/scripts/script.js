async function crearCelu(e) {
  e.preventDefault();

  const marca = document.getElementById("marca").value;
  const modelo = document.getElementById("modelo").value;
  const gama = document.getElementById("gama").value;
  const precio = document.getElementById("precio").value;

    const dataCelu = {
        marca: marca,
        modelo: modelo,
        gama: gama,
        precio: precio
    }

    console.log(dataCelu);
  const response = await fetch("http://localhost:3000/api/productos", {
    method: "POST",
    headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://127.0.0.1:5500",
    },
    body: JSON.stringify(dataCelu)
});
}

const btn = document.getElementById("agrega-boton");

btn.addEventListener("click", crearCelu);

