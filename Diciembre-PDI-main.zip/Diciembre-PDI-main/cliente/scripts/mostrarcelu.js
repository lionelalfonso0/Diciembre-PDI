async function mostrarCelu(e){
    const info = document.getElementById("carta")
    
    const response = await fetch("http://localhost:3000/api/productos", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "http://127.0.0.1:5500",
        },
    });
    const data = await response.json();
    console.log(data);

    data.forEach(celu => {
            info.innerHTML += `
                <div id="agentes">
                    <div class="col">
                        <div class="card" style="width: 15rem; ">
                            <div class="card-body">
                                <h5 class="card-title">${celu.marca}</h5>
                                <p class="card-text">${celu.modelo}</p>
                                <p class="card-text">${celu.precio}</p>
                             </div>
                         </div>
                     </div>
                </div>
`;
    });
}

mostrarCelu();