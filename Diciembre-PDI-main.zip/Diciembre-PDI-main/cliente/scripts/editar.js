async function editarCelu(idCelu) {
    const marca = document.getElementById("marca").value;
    const modelo = document.getElementById("modelo").value;
    const precio = document.getElementById("precio").value;
  
      const dataCelu = {
          marca: marca,
          modelo: modelo,
          precio: precio
      }
  
      console.log(dataCelu);
    const response = await fetch(`http://localhost:3000/api/productos/${idCelu}`, {
      method: "PUT",
      headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "http://127.0.0.1:5500",
      },
      body: JSON.stringify(dataCelu)
  });
}

async function mostrarCelu(e){
    const info = document.getElementById("carton")
    
    const response = await fetch("http://localhost:3000/api/productos", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "http://127.0.0.1:5500",
        },
    });
    const data = await response.json();

    data.forEach(celu => {
            info.innerHTML += `
                <div id="agentes">
                    <div class="col">
                        <div class="card" style="width: 15rem; ">
                            <div class="card-body">
                                <h2>Editar Celular</h2>
                                <div>
                                    <label for="marca">Marca</label>
                                    <input id="marca" placeholder="${celu.marca}">
                                </div>

                                <div>
                                    <label for="modelo">Modelo</label>
                                    <input id="modelo" placeholder="${celu.modelo}">
                                </div>

                                <div>
                                    <label for="precio">Precio</label>
                                    <input id="precio" placeholder="${celu.precio}">
                                </div>
                                <button type="button" class="btn btn-danger w-100" data-id="${celu.id}">Editar</button>
                             </div>
                         </div>
                     </div>
                </div>
`;
    });
    info.querySelectorAll('.btn-danger').forEach(boton => boton.addEventListener('click', async function() {
        const idCelu = Number(this.getAttribute('data-id'));

        console.log(`ID Celu: ${idCelu} Tipo:${typeof(idCelu)}`);
        
        await editarCelu(idCelu);
    }
    ));
    
}

mostrarCelu();


  
  