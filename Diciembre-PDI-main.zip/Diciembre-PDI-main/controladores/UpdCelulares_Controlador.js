const Celulares = require('../modelos/celulares_modelos');

const actualizacion = async (req, res) => {
    const { id } = req.params;
    const { precio, marca, modelo } = req.body;

    try {
        const celus = await Celulares.findOne ({ where: { id } });
        if (!celus) return res.json({ error: 'Celular no encontrado', detalles: error.message });
    
        celus.precio = precio;
        celus.marca = marca;
        celus.modelo = modelo;
        
        await celus.save();
        res.json(celus);
    } catch (error) {
        res.json({ error: 'No se pudo actualizar el precio', detalles: error.message });
    }
};

module.exports = actualizacion;