const Celulares = require('../modelos/celulares_modelos');

const Borrar = async (req, res) => {
    const { id } = req.params;

    try {
        const eliminar = await Celulares.destroy ({ where: { id } });
        if (!eliminar) return res.json({ error: 'Celular no encontrado' });
       
        res.send();
        
    } catch (error) {
        res.json({ error: 'No se pudo eliminar' });
    }
};

module.exports = Borrar;